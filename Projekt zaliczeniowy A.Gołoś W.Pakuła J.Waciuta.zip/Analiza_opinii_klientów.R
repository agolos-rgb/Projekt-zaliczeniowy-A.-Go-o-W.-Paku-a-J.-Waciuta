#---
#  title: "Analiza opinii klientów"
#author: "Adam Gołoś, Wojciech Pakuła, Jan Waciuta"
#date: "31.05.2026"
#output:
#  html_document:
#  df_print: paged
#theme: readable      # Wygląd
#highlight: kate      # Kolorowanie składni
#toc: true            # Spis treści
#toc_depth: 3
#toc_float:
#  collapsed: false
#smooth_scroll: true
#code_folding: show   
#number_sections:false
#---
  
knitr::opts_chunk$set(
  message = FALSE,
  warning = FALSE
)

#' #  Instalacja i Ładowanie Bibliotek
## 1. Instalacja i Ładowanie Bibliotek----


  

required_packages <- c("dplyr", "readr", "tidytext", "stringr", "wordcloud", 
                       "tidyr", "tm", "ggplot2", "forcats", "textdata")

for(p in required_packages) {
  if(!require(p, character.only = TRUE)) {
    install.packages(p, dependencies = TRUE)
    library(p, character.only = TRUE)
  }
}

#' #  Wczytanie i Oczyszczanie Pliku CSV
## 2. Wczytanie i Oczyszczanie Pliku CSV----



sciezka_do_pliku <- file.choose()

# Wczytujemy plik linia po linii jako surowy tekst
linie <- readLines(sciezka_do_pliku, encoding = "UTF-8", warn = FALSE)

# Pozbywamy się śmieci na górze (szukamy nagłówka "business_name")
start_idx <- grep("^business_name", linie)[1]
if (!is.na(start_idx) && start_idx > 1) {
  linie <- linie[start_idx:length(linie)]
}

# Usuwamy białe znaki i puste średniki na końcu każdej linii
linie <- trimws(linie)
linie <- gsub(";+$", "", linie)

# Uwalnianie linii uwięzionych w cudzysłowach
for (i in seq_along(linie)) {
  if (startsWith(linie[i], "\"") && endsWith(linie[i], "\"")) {
    linie[i] <- substr(linie[i], 2, nchar(linie[i]) - 1)
    linie[i] <- gsub('""', '"', linie[i])
  }
}

# Wczytanie naprawionego tekstu
df <- read_csv(I(paste(linie, collapse = "\n")), show_col_types = FALSE)

# Wymuszenie 6 głównych kolumn
if(ncol(df) > 6) {
  df <- df[, 1:6]
}

if (!"text" %in% colnames(df)) {
  colnames(df)[3] <- "text" 
}

df$business_name <- trimws(df$business_name)
df <- df %>% mutate(doc_id = row_number())

#' #  Wybór Restauracji i Tokenizacja
## 3. Wybór Restauracji i Tokenizacja----



wybrana_restauracja <- "Kocak Baklava"

df_restauracja <- df %>% filter(business_name == wybrana_restauracja)

moje_stopwords <- data.frame(word = c("recommend" ,"restaurant", "taste", "food", "and", "delicious", "nice", "service", "eat", "restaurant", "place", "pizza", "marmaris", "istanbul"))

tidy_reviews <- df_restauracja %>%
  unnest_tokens(word, text, to_lower = TRUE) %>%
  anti_join(stop_words, by = "word") %>%
  anti_join(moje_stopwords, by = "word") %>%
  filter(!str_detect(word, "^[0-9]+$"))

#' # Chmura Słów (Waga TF-IDF)
## 4. Chmura Słów (Waga TF-IDF)----

tfidf_words <- tidy_reviews %>%
  count(doc_id, word, sort = TRUE) %>%
  bind_tf_idf(word, doc_id, n)

wordcloud_data <- tfidf_words %>%
  group_by(word) %>%
  summarise(waga_tfidf = sum(tf_idf)) %>%
  arrange(desc(waga_tfidf))

if(nrow(wordcloud_data) > 0) {
  wordcloud(words = wordcloud_data$word, freq = ceiling(wordcloud_data$waga_tfidf * 100), 
            max.words = 60, colors = brewer.pal(8, "Dark2"))
}
#' # Segmentacja Klientów (K-Means)
## 5. Segmentacja Klientów (K-Means)----

dtm_tfidf <- tfidf_words %>% cast_dtm(doc_id, word, tf_idf)
dtm_sparse <- removeSparseTerms(dtm_tfidf, 0.99)

liczba_dokumentow <- nrow(dtm_sparse)

if (liczba_dokumentow < 3) {
  cat("Zbyt mało unikalnych opinii do wykonania grupowania (wymagane min. 3).\n")
  tidy_reviews_clustered <- tidy_reviews %>% mutate(cluster = as.factor(1))
} else {
  set.seed(123)
  kmeans_result <- kmeans(as.matrix(dtm_sparse), centers = 3)
  clusters <- data.frame(doc_id = as.integer(names(kmeans_result$cluster)), 
                         cluster = as.factor(kmeans_result$cluster))
  tidy_reviews_clustered <- tidy_reviews %>% inner_join(clusters, by = "doc_id")
  
  # Wizualizacja dla poszczególnych klastrów
  layout(matrix(1:3, 1, 3))
  for (i in 1:3) {
    cluster_data <- tidy_reviews_clustered %>% filter(cluster == i)
    cluster_words <- cluster_data %>% count(word, sort = TRUE)
    
    if(nrow(cluster_words) > 0) {
      wordcloud(words = cluster_words$word, freq = cluster_words$n, 
                max.words = 40, colors = brewer.pal(8, "Set1"))
      title(paste("Klaster", i))
    }
  }
}
#' #Strategiczna Rekomendacja dla Kampanii
## 6. Strategiczna Rekomendacja dla Kampanii----


wielkosc_klastrow <- table(tidy_reviews_clustered$cluster)
najwiekszy_klaster <- names(wielkosc_klastrow)[which.max(wielkosc_klastrow)]
dane_najwiekszego <- tidy_reviews_clustered %>% filter(cluster == najwiekszy_klaster)

top_slowa_kampania <- dane_najwiekszego %>% 
  count(word, sort = TRUE) %>% 
  head(5) %>% 
  pull(word)

sentyment_kampania <- dane_najwiekszego %>%
  inner_join(get_sentiments("bing"), by = "word") %>%
  count(sentiment) %>%
  pivot_wider(names_from = sentiment, values_from = n, values_fill = list(n = 0))

poz <- if("positive" %in% names(sentyment_kampania)) sentyment_kampania$positive else 0
neg <- if("negative" %in% names(sentyment_kampania)) sentyment_kampania$negative else 0

cat("### Obiekt: ", wybrana_restauracja, "\n\n")
cat("> **Największy segment klientów (Klaster ", najwiekszy_klaster, ") generuje najwięcej wartości analitycznej.**\n\n", sep="")
cat("**Słowa najczęściej używane przez tę grupę docelową to:** ", paste(toupper(top_slowa_kampania), collapse = ", "), "\n\n")

if (poz >= neg) {
  cat("**DIAGNOZA:** Wydźwięk emocjonalny tego dominującego segmentu jest **POZYTYWNY**.\n\n")
  cat("**ZALECENIA KAMPANIJNE:**\n")
  cat("* **Komunikacja wprost:** Wykorzystaj powyższe słowa jako główne atuty w swoich materiałach reklamowych.\n")
  cat("* **Pozycjonowanie:** Kampania powinna podkreślać te mocne strony, aby przyciągnąć szersze grono klientów.\n")
} else {
  cat("**DIAGNOZA:** Wydźwięk emocjonalny tego dominującego segmentu jest **NEGATYWNY**.\n\n")
  cat("**ZALECENIA KAMPANIJNE:**\n")
  cat("* **Kampania naprawcza (Damage Control):** Przed startem płatnych reklam należy operacyjnie naprawić błędy.\n")
  cat("* **Komunikacja:** Kampania powinna opierać się na przekazie \"Słuchamy Was - zmieniliśmy się na lepsze\".\n")
}
#' #Zaawansowane Wykresy Sentymentu
## 7. Zaawansowane Wykresy Sentymentu----


### Słownik Bing (Biegunowy)
word_counts_bing <- tidy_reviews %>%
  inner_join(get_sentiments("bing"), by = "word") %>%
  count(word, sentiment, sort = TRUE) %>%
  group_by(sentiment) %>%
  slice_max(n, n = 10, with_ties = FALSE) %>%
  ungroup() %>%
  mutate(word = reorder_within(word, n, sentiment))

ggplot(word_counts_bing, aes(x = word, y = n, fill = sentiment)) + 
  geom_col(show.legend = FALSE) +
  facet_wrap(~sentiment, scales = "free_y") +
  coord_flip() +
  scale_x_reordered() + 
  labs(x = "Słowa", y = "Liczba wystąpień", title = paste("Słownik Bing -", wybrana_restauracja)) +
  theme_minimal() + 
  scale_fill_manual(values = c("negative" = "goldenrod1", "positive" = "dodgerblue4"))

### Słownik NRC (Złożony)

word_counts_nrc <- tidy_reviews %>%
  inner_join(get_sentiments("nrc"), by = "word", relationship = "many-to-many") %>%
  filter(sentiment %in% c("positive", "negative")) %>%
  count(word, sentiment, sort = TRUE) %>%
  group_by(sentiment) %>%
  slice_max(n, n = 10, with_ties = FALSE) %>%
  ungroup() %>%
  mutate(word = reorder_within(word, n, sentiment))

ggplot(word_counts_nrc, aes(x = word, y = n, fill = sentiment)) + 
  geom_col(show.legend = FALSE) +
  facet_wrap(~sentiment, scales = "free_y") +
  coord_flip() +
  scale_x_reordered() +
  labs(x = "Słowa", y = "Liczba wystąpień", title = paste("Słownik NRC -", wybrana_restauracja)) +
  theme_minimal()

### Słownik Loughran (Kontekst Finansowy)

word_counts_loughran <- tidy_reviews %>%
  inner_join(get_sentiments("loughran"), by = "word", relationship = "many-to-many") %>%
  filter(sentiment %in% c("positive", "negative")) %>%
  count(word, sentiment, sort = TRUE) %>%
  group_by(sentiment) %>%
  slice_max(n, n = 10, with_ties = FALSE) %>%
  ungroup() %>%
  mutate(word = reorder_within(word, n, sentiment))

if(nrow(word_counts_loughran) > 0) {
  ggplot(word_counts_loughran, aes(x = word, y = n, fill = sentiment)) + 
    geom_col(show.legend = FALSE) +
    facet_wrap(~sentiment, scales = "free_y") +
    coord_flip() +
    scale_x_reordered() +
    labs(x = "Słowa", y = "Liczba wystąpień", title = paste("Słownik Loughran -", wybrana_restauracja)) +
    theme_minimal() + 
    scale_fill_manual(values = c("negative" = "firebrick", "positive" = "darkolivegreen4"))
}

### Słownik AFINN (Skala Punktowa)

word_counts_afinn <- tidy_reviews %>%
  inner_join(get_sentiments("afinn"), by = "word") %>%
  filter(value %in% c(-5, -4, -3, 3, 4, 5)) %>% 
  count(word, value, sort = TRUE) %>%
  group_by(value) %>%
  slice_max(n, n = 10, with_ties = FALSE) %>%
  ungroup() %>%
  mutate(word = reorder_within(word, n, value),
         value = as.factor(value)) 

if(nrow(word_counts_afinn) > 0) {
  ggplot(word_counts_afinn, aes(x = word, y = n, fill = value)) + 
    geom_col(show.legend = FALSE) +
    facet_wrap(~value, scales = "free_y") +
    coord_flip() +
    scale_x_reordered() +
    labs(x = "Słowa", y = "Liczba wystąpień", title = paste("Słownik AFINN -", wybrana_restauracja)) +
    theme_minimal()
}

